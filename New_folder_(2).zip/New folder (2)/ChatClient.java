import java.awt.*;
import java.awt.event.*;
import java.io.*;
import java.net.*;
import java.util.ArrayList;

public class ChatClient extends Frame {
    private static final String SERVER_ADDRESS = "localhost";
    private static final int PORT = 12345;
    private TextArea receiveTextArea;
    private TextField sendTextField;
    private PrintWriter out;
    private String username;
    private ArrayList<String> userNamesList; // List to store usernames
    private TextArea userListTextArea; // TextArea to display usernames

    public ChatClient(String username) {
        this.username = username;
        setTitle("Chat Client - " + username);
        setSize(500, 500);
        setLayout(null);

        receiveTextArea = new TextArea();
        receiveTextArea.setEditable(false);
        receiveTextArea.setBounds(10, 35, 340, 400);
        receiveTextArea.setFont(new Font("Arial", Font.PLAIN, 16));
        add(receiveTextArea);

        sendTextField = new TextField();
        sendTextField.setBounds(10, 435, 340, 50);
        add(sendTextField);

        Button sendButton = new Button("Send");
        sendButton.setBounds(370, 450, 115, 30);
        sendButton.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                sendMessage();
            }
        });
        add(sendButton);

        userListTextArea = new TextArea();
        userListTextArea.setEditable(false);
        userListTextArea.setBounds(355, 35, 200, 400);
        add(userListTextArea);

        addWindowListener(new WindowAdapter() {
            public void windowClosing(WindowEvent e) {
                System.exit(0);
            }
        });

        userNamesList = new ArrayList<>(); // Initialize the list

        try {
            Socket socket = new Socket(SERVER_ADDRESS, PORT);
            out = new PrintWriter(socket.getOutputStream(), true);
            BufferedReader in = new BufferedReader(new InputStreamReader(socket.getInputStream()));

            Thread receiveThread = new Thread(() -> {
                try {
                    String message;
                    while ((message = in.readLine()) != null) {
                        if (message.startsWith("[USERNAME]")) {
                            String newUser = message.substring(10); // Extract username
                            userNamesList.add(newUser); // Add username to the list
                            updateUserListTextArea(); // Update the user list TextArea
                        } else {
                            receiveMessage(message);
                        }
                    }
                } catch (IOException e) {
                    e.printStackTrace();
                }
            });
            receiveThread.start();

            // Announce new user to server
            out.println("[USERNAME]" + username); // Send username to the server
        } catch (IOException e) {
            e.printStackTrace();
        }

        setVisible(true);
    }

    private void sendMessage() {
        String message = sendTextField.getText();
        if (!message.isEmpty()) {
            out.println(username + ": " + message);
            sendTextField.setText("");
            receiveTextArea.append(username + ": " + message + "\n");
        }
    }

    private void receiveMessage(String message) {
        receiveTextArea.append(message + "\n");
    }

    // Update the user list TextArea with the current list of usernames
    private void updateUserListTextArea() {
        userListTextArea.setText(""); // Clear existing content
        for (String user : userNamesList) {
            userListTextArea.append(user + "\n");
        }
    }

    public static void main(String[] args) {
        if (args.length != 1) {
            System.err.println("Usage: java ChatClient <username>");
            System.exit(1);
        }

        new ChatClient(args[0]);
    }
}